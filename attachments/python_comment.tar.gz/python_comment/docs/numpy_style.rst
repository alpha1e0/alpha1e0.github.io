numpy\_style module
===================

.. automodule:: numpy_style
    :members:
    :undoc-members:
    :show-inheritance:
