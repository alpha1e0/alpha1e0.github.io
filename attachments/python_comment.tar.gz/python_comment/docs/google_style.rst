google\_style module
====================

.. automodule:: google_style
    :members:
    :undoc-members:
    :show-inheritance:
