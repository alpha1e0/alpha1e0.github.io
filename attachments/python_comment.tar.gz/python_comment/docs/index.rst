.. python_comment documentation master file, created by
   sphinx-quickstart on Sun Oct  7 00:02:40 2018.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to python_comment's documentation!
==========================================

.. toctree::
   :maxdepth: 2

   modules

.. toctree::
   :maxdepth: 2
   :caption: Contents:



Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
