sphinx\_style module
====================

.. automodule:: sphinx_style
    :members:
    :undoc-members:
    :show-inheritance:
