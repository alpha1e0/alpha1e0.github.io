# -*- coding: utf-8 -*-
"""Example Sphinx style docstrings.

This module demonstrates documentation as specified by the 
`Sphinx Python Style Guide`_. Docstrings may extend over multiple lines. 
Sections are created with a section header and a colon followed by a 
block of indented text.

Example:
    Examples can be given using either the ``Example`` or ``Examples``
    sections. Sections support any reStructuredText formatting, including
    literal blocks::

        $ python example_google.py

Section breaks are created by resuming unindented text. Section breaks
are also implicitly created anytime a new section starts.

Todo:
    * For module TODOs
    * You have to also use ``sphinx.ext.todo`` extension

.. _Sphinx Python Style Guide:
   https://pythonhosted.org/an_example_pypi_project/sphinx.html#full-code-example

"""

module_level_variable1 = 12345

module_level_variable2 = 98765


def function_with_types_in_docstring(param1, param2):
    """Example function with types documented in the docstring.

    `PEP 484`_ type annotations are supported. If attribute, parameter, and
    return types are annotated according to `PEP 484`_, they do not need to be
    included in the docstring:

    :param param1: The first parameter.
    :type param1: int
    :param param2: The second parameter.
    :type param2: str

    :returns: The return value. True for success, False otherwise.
    :rtype: bool

    .. _PEP 484:
        https://www.python.org/dev/peps/pep-0484/

    """


def function_with_pep484_type_annotations(param1: int, param2: str) -> bool:
    """Example function with PEP 484 type annotations.

    :param param1: The first parameter.
    :param param2: The second parameter.

    :returns: The return value. True for success, False otherwise.

    """


class ExampleClass(object):
    """The summary line for a class docstring should fit on one line.
    """

    def __init__(self, param1, param2, param3):
        """Example of docstring on the __init__ method.

        The __init__ method may be documented in either the class level
        docstring, or as a docstring on the __init__ method itself.

        Either form is acceptable, but the two should not be mixed. Choose one
        convention to document the __init__ method and be consistent with it.

        Note:
            Do not include the `self` parameter in the ``Args`` section.

        :param param1: The first parameter.
        :type param1: str
        :param param2: The second parameter.
        :type param2: int
        :param param3: The third parameter.

        """
        self.attr1 = param1
        self.attr2 = param2
        self.attr3 = param3  #: Doc comment *inline* with attribute

        #: list(str): Doc comment *before* attribute, with type specified
        self.attr4 = ['attr4']

        self.attr5 = None
        """str: Docstring *after* attribute, with type specified."""


    def example_method(self, param1, param2):
        """Class methods are similar to regular functions.

        Note:
            Do not include the `self` parameter in the ``Args`` section.

        :param param1: The first parameter.
        :type param1: str
        :param param2: The second parameter.
        :type param2: int

        :returns: The return value. True for success, False otherwise.
        :rtype: bool

        """
        return True

    def __special__(self):
        """By default special members with docstrings are not included.

        Special members are any methods or attributes that start with and
        end with a double underscore. Any special member with a docstring
        will be included in the output, if
        ``napoleon_include_special_with_doc`` is set to True.

        This behavior can be enabled by changing the following setting in
        Sphinx's conf.py::

            napoleon_include_special_with_doc = True

        """
        pass

    def __special_without_docstring__(self):
        pass

    def _private(self):
        """By default private members are not included.

        Private members are any methods or attributes that start with an
        underscore and are *not* special. By default they are not included
        in the output.

        This behavior can be changed such that private members *are* included
        by changing the following setting in Sphinx's conf.py::

            napoleon_include_private_with_doc = True

        """
        pass

    def _private_without_docstring(self):
        pass
